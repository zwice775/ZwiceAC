# Zwice AC (Paper 1.21.11)

Derleme: `mvn clean package` (Java 21) -> `target/ZwiceAC-1.0.0.jar` dosyasını `plugins/` klasörüne at.

Komutlar: /zac help | alerts | info <oyuncu> | reset <oyuncu> | exempt <oyuncu> | reload
İzinler: zwiceac.admin, zwiceac.alerts, zwiceac.bypass

Kontroller: Fly, Speed, Step, Jesus, NoFall, NoSlow, FastLadder, Phase/NoClip, Timer, BadPackets,
Velocity (AntiKB), Reach, KillAura, AutoClicker, FastPlace, Scaffold, BlockReach, FastBreak, Nuker, Xray.
Hepsi config.yml'den açılıp kapatılabilir, VL ve ceza eşikleri ayarlanabilir.
