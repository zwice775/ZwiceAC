package dev.zwice.ac;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ZwiceCommand implements CommandExecutor, TabCompleter {

    private static final String PREFIX = "&8[&bZwice&3AC&8] ";
    private final ZwiceAC plugin;

    public ZwiceCommand(ZwiceAC plugin) {
        this.plugin = plugin;
    }

    private void msg(CommandSender s, String m) {
        s.sendMessage(ViolationManager.color(PREFIX + m));
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            msg(s, "&7Komutlar:");
            msg(s, "&b/zac alerts &8- &7Uyarıları aç/kapat");
            msg(s, "&b/zac info <oyuncu> &8- &7İhlal geçmişi");
            msg(s, "&b/zac reset <oyuncu> &8- &7VL sıfırla");
            msg(s, "&b/zac exempt <oyuncu> &8- &7Muafiyet aç/kapat");
            msg(s, "&b/zac reload &8- &7Ayarları yenile");
            return true;
        }

        String sub = a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("alerts")) {
            if (!(s instanceof Player p) || !p.hasPermission("zwiceac.alerts")) {
                msg(s, "&cBunu kullanamazsın.");
                return true;
            }
            boolean on = plugin.violations().toggleAlerts(p.getUniqueId());
            msg(s, "&7Uyarılar: " + (on ? "&aAçık" : "&cKapalı"));
            return true;
        }

        if (!s.hasPermission("zwiceac.admin")) {
            msg(s, "&cYetkin yok.");
            return true;
        }

        switch (sub) {
            case "reload" -> {
                plugin.reloadConfig();
                msg(s, "&aAyarlar yenilendi.");
            }
            case "info", "reset", "exempt" -> {
                if (a.length < 2) {
                    msg(s, "&cKullanım: /zac " + sub + " <oyuncu>");
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    msg(s, "&cOyuncu bulunamadı.");
                    return true;
                }
                PlayerData d = plugin.data(t);
                if (sub.equals("info")) {
                    msg(s, "&f" + t.getName() + " &7| Ping: &f" + t.getPing() + "ms &7| Muaf: &f" + d.exempt);
                    if (d.vl.isEmpty()) {
                        msg(s, "&aİhlal yok.");
                    } else {
                        for (Map.Entry<String, Double> en : d.vl.entrySet()) {
                            msg(s, "&c" + en.getKey() + " &8» &e" + String.format(Locale.ROOT, "%.1f", en.getValue()));
                        }
                    }
                } else if (sub.equals("reset")) {
                    d.vl.clear();
                    msg(s, "&a" + t.getName() + " için VL sıfırlandı.");
                } else {
                    d.exempt = !d.exempt;
                    msg(s, "&f" + t.getName() + " &7muafiyet: " + (d.exempt ? "&aAçık" : "&cKapalı"));
                }
            }
            default -> msg(s, "&cBilinmeyen alt komut. /zac help");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("help", "alerts", "info", "reset", "exempt", "reload")) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        } else if (a.length == 2 && List.of("info", "reset", "exempt").contains(a[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }
}
