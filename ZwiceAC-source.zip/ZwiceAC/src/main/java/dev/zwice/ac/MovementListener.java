package dev.zwice.ac;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Tag;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Locale;

public final class MovementListener implements Listener {

    private final ZwiceAC plugin;

    public MovementListener(ZwiceAC plugin) {
        this.plugin = plugin;
    }

    private String f(double v) { return String.format(Locale.ROOT, "%.3f", v); }

    /** Flag atar, iptal gerekiyorsa oyuncuyu güvenli konuma geri çeker. */
    private boolean flag(PlayerMoveEvent e, Player p, PlayerData d, String check, String info, double add) {
        boolean cancel = plugin.violations().flag(p, check, info, add);
        if (cancel) {
            Location safe = d.lastSafe != null && d.lastSafe.getWorld() == p.getWorld() ? d.lastSafe : e.getFrom();
            e.setTo(safe.clone());
            d.lastTeleport = System.currentTimeMillis();
            d.resetMotion();
            return true;
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!plugin.shouldCheck(p)) return;

        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null || from.getWorld() != to.getWorld()) return;

        PlayerData d = plugin.data(p);
        long now = System.currentTimeMillis();

        // ---- BadPackets ----
        if (plugin.enabled("badpackets")) {
            float pitch = to.getPitch();
            if (Math.abs(pitch) > 90.0F || Float.isNaN(pitch) || Float.isNaN(to.getYaw())) {
                if (flag(e, p, d, "badpackets", "pitch=" + pitch, 1)) return;
            }
        }

        // ---- Timer ----
        if (plugin.enabled("timer")) {
            d.moveCount++;
            if (now - d.windowStart >= 1000) {
                double max = plugin.num("checks.timer.max-moves-per-second", 38);
                if (d.moveCount > max && !plugin.laggy(p)) {
                    double b = d.addBuffer("timer", 1);
                    if (b >= 3) flag(e, p, d, "timer", d.moveCount + " pkt/s", 1);
                } else {
                    d.addBuffer("timer", -1);
                }
                d.moveCount = 0;
                d.windowStart = now;
            }
        }

        // Sadece rotasyon değişimi ise hareket kontrollerini atla
        if (from.getX() == to.getX() && from.getY() == to.getY() && from.getZ() == to.getZ()) return;

        if (plugin.laggy(p)) {
            d.resetMotion();
            return;
        }

        double dx = to.getX() - from.getX();
        double dy = to.getY() - from.getY();
        double dz = to.getZ() - from.getZ();
        double h = Math.hypot(dx, dz);

        boolean special = MoveUtil.special(to) || MoveUtil.special(from)
                || p.isInWater() || p.isInLava() || p.isClimbing();
        if (special) d.lastSpecial = now;
        boolean specialRecent = now - d.lastSpecial < 1000;
        if (MoveUtil.onIce(to)) d.lastIce = now;

        boolean gTo = MoveUtil.onGround(p, to, 0.03);
        boolean gFrom = d.lastGround;

        boolean levitating = p.hasPotionEffect(PotionEffectType.LEVITATION)
                || p.hasPotionEffect(PotionEffectType.SLOW_FALLING);

        boolean exempt = now - d.lastTeleport < 1500
                || now - d.lastVelocity < 1500
                || p.isFlying() || p.getAllowFlight() || p.isGliding()
                || p.isInsideVehicle() || p.isRiptiding() || p.isDead() || p.isSleeping();

        if (exempt) {
            d.airTicks = 0;
            d.waterTicks = 0;
            d.lastDy = dy;
            d.lastH = h;
            d.lastGround = gTo;
            if (gTo) d.lastSafe = to.clone();
            return;
        }

        // ---- Phase / NoClip ----
        if (plugin.enabled("phase")) {
            if (MoveUtil.collides(to.getWorld(), MoveUtil.box(p, to, 0.03))
                    && !MoveUtil.collides(from.getWorld(), MoveUtil.box(p, from, 0.03))) {
                if (flag(e, p, d, "phase", "blok içine girdi", 2)) return;
            }
        }

        // ---- Fly / Hover / Spider / Glide ----
        if (plugin.enabled("fly") && !specialRecent && !levitating) {
            if (gTo) {
                d.airTicks = 0;
                d.addBuffer("fly", -1);
            } else {
                d.airTicks++;
                if (d.airTicks >= 3) {
                    double expected = (d.lastDy - 0.08) * 0.98;
                    double diff = dy - expected;
                    if (diff > plugin.num("checks.fly.tolerance", 0.03)) {
                        double b = d.addBuffer("fly", 1);
                        if (b >= 4 && flag(e, p, d, "fly", "dy=" + f(dy) + " exp=" + f(expected), 1)) return;
                    } else {
                        d.addBuffer("fly", -0.25);
                    }
                }
            }
        } else {
            d.airTicks = 0;
        }

        // ---- NoFall (sahte onGround) ----
        if (plugin.enabled("nofall") && !specialRecent && dy < -0.08 && p.isOnGround()
                && !MoveUtil.onGround(p, to, 0.2)) {
            double b = d.addBuffer("nofall", 1);
            if (b >= 3 && flag(e, p, d, "nofall", "ground spoof dy=" + f(dy), 1)) return;
        } else if (gTo) {
            d.addBuffer("nofall", -0.5);
        }

        // ---- Speed ----
        if (plugin.enabled("speed") && !specialRecent) {
            boolean air = !gTo || !gFrom;
            double allowed = air ? plugin.num("checks.speed.air-limit", 0.62)
                    : plugin.num("checks.speed.ground-limit", 0.36);
            PotionEffect speed = p.getPotionEffect(PotionEffectType.SPEED);
            if (speed != null) allowed *= 1.0 + 0.2 * (speed.getAmplifier() + 1);
            allowed *= Math.max(1.0, p.getWalkSpeed() / 0.2);
            if (now - d.lastIce < 1500) allowed *= 1.8;
            if (h > allowed) {
                double b = d.addBuffer("speed", 1 + Math.min(2.0, (h - allowed) / allowed * 4));
                if (b >= 4 && flag(e, p, d, "speed", f(h) + " > " + f(allowed), 1)) return;
            } else {
                d.addBuffer("speed", -0.25);
            }
        }

        // ---- NoSlow (item kullanırken yavaşlamama) ----
        if (plugin.enabled("noslow") && gTo && gFrom && !specialRecent && p.isHandRaised()
                && now - d.lastIce > 1500) {
            double max = plugin.num("checks.noslow.max-speed", 0.13);
            PotionEffect speed = p.getPotionEffect(PotionEffectType.SPEED);
            if (speed != null) max *= 1.0 + 0.2 * (speed.getAmplifier() + 1);
            if (h > max) {
                double b = d.addBuffer("noslow", 1);
                if (b >= 5 && flag(e, p, d, "noslow", f(h) + " > " + f(max), 1)) return;
            } else {
                d.addBuffer("noslow", -0.5);
            }
        }

        // ---- Step ----
        if (plugin.enabled("step") && gFrom && gTo && !specialRecent) {
            double maxH = plugin.num("checks.step.max-height", 0.7);
            if (dy > maxH) {
                if (flag(e, p, d, "step", "dy=" + f(dy), 1)) return;
            }
        }

        // ---- FastLadder ----
        if (plugin.enabled("fastladder") && Tag.CLIMBABLE.isTagged(to.getBlock().getType())
                && !p.hasPotionEffect(PotionEffectType.JUMP_BOOST)) {
            double max = plugin.num("checks.fastladder.max-speed", 0.26);
            if (dy > max) {
                double b = d.addBuffer("fastladder", 1);
                if (b >= 2 && flag(e, p, d, "fastladder", "dy=" + f(dy), 1)) return;
            } else {
                d.addBuffer("fastladder", -0.5);
            }
        }

        // ---- Jesus / WaterWalk ----
        if (plugin.enabled("jesus")) {
            Location below = to.clone().subtract(0, 0.1, 0);
            boolean onLiquid = below.getBlock().isLiquid() && !to.getBlock().isLiquid()
                    && !p.isInWater() && !gTo;
            if (onLiquid && Math.abs(dy) < 0.02 && h > 0.05) {
                d.waterTicks++;
                if (d.waterTicks > 6 && flag(e, p, d, "jesus", "sıvı üstünde yürüyor", 1)) return;
            } else {
                d.waterTicks = 0;
            }
        }

        // Güvenli konum güncelle
        if (gTo) d.lastSafe = to.clone();
        d.lastDy = dy;
        d.lastH = h;
        d.lastGround = gTo;
    }

    // ---- AntiKnockback / Velocity ----
    @EventHandler(ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent e) {
        Player p = e.getPlayer();
        PlayerData d = plugin.data(p);
        d.lastVelocity = System.currentTimeMillis();

        if (!plugin.shouldCheck(p) || !plugin.enabled("velocity")) return;
        Vector v = e.getVelocity();
        double horiz = Math.hypot(v.getX(), v.getZ());
        if (horiz < 0.35) return;

        Location start = p.getLocation().clone();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline() || p.isDead() || p.isInsideVehicle() || p.isFlying()
                    || p.isGliding() || p.isRiptiding()) return;
            Location end = p.getLocation();
            if (end.getWorld() != start.getWorld()) return;
            if (end.distanceSquared(start) < 1.0E-12 && MoveUtil.obstructed(end)) return;
            if (MoveUtil.obstructed(end) || MoveUtil.special(end) || p.isInWater()) return;
            if (plugin.laggy(p)) return;
            double moved = Math.hypot(end.getX() - start.getX(), end.getZ() - start.getZ());
            if (moved < 0.08) {
                double b = d.addBuffer("velocity", 1);
                if (b >= 3) {
                    plugin.violations().flag(p, "velocity",
                            "kb=" + f(horiz) + " moved=" + f(moved), 1);
                    d.resetBuffer("velocity");
                }
            } else {
                d.addBuffer("velocity", -1);
            }
        }, 6L);
    }
}
