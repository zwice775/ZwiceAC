package dev.zwice.ac;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.util.RayTraceResult;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;

public final class WorldListener implements Listener {

    private static final Set<Material> RARE_ORES = EnumSet.of(
            Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE, Material.ANCIENT_DEBRIS,
            Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE);

    private static final BlockFace[] FACES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    private final ZwiceAC plugin;

    public WorldListener(ZwiceAC plugin) {
        this.plugin = plugin;
    }

    private String f(double v) { return String.format(Locale.ROOT, "%.2f", v); }

    // ---------------- Blok koyma ----------------
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (!plugin.shouldCheck(p)) return;
        PlayerData d = plugin.data(p);
        ViolationManager vm = plugin.violations();
        long now = System.currentTimeMillis();

        // FastPlace
        if (plugin.enabled("fastplace")) {
            int c = d.record(d.places, now, 1000);
            if (c > plugin.num("checks.fastplace.max-per-second", 14)) {
                if (vm.flag(p, "fastplace", c + " blok/sn", 1)) {
                    e.setCancelled(true);
                    return;
                }
            }
        }

        if (!plugin.enabled("scaffold")) return;
        Block against = e.getBlockAgainst();
        double reach = plugin.num("checks.scaffold.reach", 5.8);

        // Mesafe
        double dist = p.getEyeLocation().distance(against.getLocation().add(0.5, 0.5, 0.5));
        if (dist > reach) {
            if (vm.flag(p, "scaffold", "mesafe=" + f(dist), 1)) {
                e.setCancelled(true);
                return;
            }
        }

        // Baktığı blok ile yerleştirdiği blok uyuşuyor mu? (Scaffold/Tower/Legit-scaffold)
        RayTraceResult r = p.rayTraceBlocks(reach);
        if (r == null || r.getHitBlock() == null || !r.getHitBlock().equals(against)) {
            double b = d.addBuffer("scaffold", 1);
            if (b >= 4) {
                d.resetBuffer("scaffold");
                if (vm.flag(p, "scaffold", "baktığı bloğa koymuyor", 1)) e.setCancelled(true);
            }
        } else {
            d.addBuffer("scaffold", -0.5);
        }
    }

    // ---------------- Blok kırma ----------------
    @EventHandler(ignoreCancelled = true)
    public void onDamage(BlockDamageEvent e) {
        Player p = e.getPlayer();
        PlayerData d = plugin.data(p);
        d.digLoc = e.getBlock().getLocation();
        d.digStart = System.currentTimeMillis();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!plugin.shouldCheck(p)) return;
        PlayerData d = plugin.data(p);
        ViolationManager vm = plugin.violations();
        Block b = e.getBlock();
        long now = System.currentTimeMillis();

        // BlockReach
        if (plugin.enabled("blockreach")) {
            double dist = p.getEyeLocation().distance(b.getLocation().add(0.5, 0.5, 0.5));
            if (dist > plugin.num("checks.blockreach.max-distance", 6.2)) {
                if (vm.flag(p, "blockreach", "mesafe=" + f(dist), 1)) {
                    e.setCancelled(true);
                    return;
                }
            }
        }

        // Nuker: saniyedeki kırma sayısı
        if (plugin.enabled("nuker")) {
            int c = d.record(d.breaks, now, 1000);
            if (c > plugin.num("checks.nuker.max-per-second", 15)) {
                if (vm.flag(p, "nuker", c + " blok/sn", 1)) {
                    e.setCancelled(true);
                    return;
                }
            }
        }

        // FastBreak + başlamadan kırma
        Location bl = b.getLocation();
        if (d.digLoc != null && d.digLoc.equals(bl)) {
            if (plugin.enabled("fastbreak")) {
                float speed = b.getBreakSpeed(p);
                if (speed > 0 && speed < 1.0f) {
                    double ticks = Math.ceil(1.0 / speed);
                    double tol = plugin.num("checks.fastbreak.tolerance", 0.6);
                    long minMs = (long) (ticks * 50.0 * tol);
                    long elapsed = now - d.digStart;
                    if (elapsed < minMs) {
                        if (vm.flag(p, "fastbreak", elapsed + "ms < " + minMs + "ms", 1)) {
                            e.setCancelled(true);
                            return;
                        }
                    }
                }
            }
            d.digLoc = null;
        } else if (plugin.enabled("nuker")) {
            double bu = d.addBuffer("nuker-nostart", 1);
            if (bu >= 3) {
                d.resetBuffer("nuker-nostart");
                if (vm.flag(p, "nuker", "kırma başlamadan blok kırdı", 1)) {
                    e.setCancelled(true);
                    return;
                }
            }
        }

        // Arkasında bakmadan kırma (duvar arkası)
        if (plugin.enabled("blockreach")) {
            RayTraceResult r = p.rayTraceBlocks(plugin.num("checks.blockreach.max-distance", 6.2));
            if (r == null || r.getHitBlock() == null || !r.getHitBlock().equals(b)) {
                double bf = d.addBuffer("break-ray", 1);
                if (bf >= 5) {
                    d.resetBuffer("break-ray");
                    if (vm.flag(p, "blockreach", "baktığı bloğu kırmıyor", 1)) {
                        e.setCancelled(true);
                        return;
                    }
                }
            } else {
                d.addBuffer("break-ray", -0.5);
            }
        }

        // Xray (istatistiksel): hiçbir yüzü açıkta olmayan nadir cevherleri doğrudan kazma
        if (plugin.enabled("xray") && RARE_ORES.contains(b.getType())) {
            boolean hidden = true;
            for (BlockFace face : FACES) {
                if (!b.getRelative(face).getType().isOccluding()) {
                    hidden = false;
                    break;
                }
            }
            if (hidden) {
                int c = d.record(d.hiddenOres, now, 600_000L);
                int limit = (int) plugin.num("checks.xray.hidden-ores-per-10min", 10);
                if (c >= limit) {
                    vm.flag(p, "xray", c + " gizli cevher/10dk", 1);
                }
            }
        }
    }
}
