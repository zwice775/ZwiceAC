package dev.zwice.ac;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ViolationManager {

    private static final Object FILE_LOCK = new Object();
    private static final LegacyComponentSerializer SER = LegacyComponentSerializer.legacyAmpersand();

    private final ZwiceAC plugin;
    private final Set<UUID> alertsOff = ConcurrentHashMap.newKeySet();

    public ViolationManager(ZwiceAC plugin) {
        this.plugin = plugin;
    }

    public static Component color(String s) {
        return SER.deserialize(s);
    }

    public boolean toggleAlerts(UUID id) {
        if (alertsOff.remove(id)) return true;
        alertsOff.add(id);
        return false;
    }

    /** @return true ise eylem/hareket iptal edilmeli. */
    public boolean flag(Player p, String check, String info, double add) {
        if (!plugin.enabled(check)) return false;
        PlayerData d = plugin.data(p);
        double vl = d.vl.merge(check, add, Double::sum);

        alert(p, d, check, info, vl);

        double max = plugin.num("checks." + check + ".max-vl", 10);
        if (vl >= max) punish(p, d, check);

        return plugin.getConfig().getBoolean("checks." + check + ".cancel", true);
    }

    private void alert(Player p, PlayerData d, String check, String info, double vl) {
        long now = System.currentTimeMillis();
        long cd = (long) plugin.num("alerts.cooldown-ms", 750);
        Long last = d.lastAlert.get(check);
        if (last != null && now - last < cd) return;
        d.lastAlert.put(check, now);

        String raw = plugin.getConfig().getString("messages.alert",
                "&8[&bZwice&3AC&8] &f%player% &7» &c%check% &8(&7%info%&8) &eVL:%vl% &8| &7%ping%ms")
                .replace("%player%", p.getName())
                .replace("%check%", check)
                .replace("%info%", info)
                .replace("%vl%", String.format(Locale.ROOT, "%.1f", vl))
                .replace("%ping%", String.valueOf(p.getPing()));
        Component msg = color(raw);

        for (Player s : Bukkit.getOnlinePlayers()) {
            if (s.hasPermission("zwiceac.alerts") && !alertsOff.contains(s.getUniqueId())) {
                s.sendMessage(msg);
            }
        }
        if (plugin.getConfig().getBoolean("alerts.console", true)) {
            plugin.getLogger().info(p.getName() + " -> " + check + " (" + info + ") VL:"
                    + String.format(Locale.ROOT, "%.1f", vl));
        }
        log(LocalDateTime.now() + " | " + p.getName() + " | " + check + " | " + info + " | VL "
                + String.format(Locale.ROOT, "%.1f", vl));
    }

    private void punish(Player p, PlayerData d, String check) {
        String announce = plugin.getConfig().getString("messages.punished", "")
                .replace("%player%", p.getName()).replace("%check%", check);
        if (!announce.isEmpty()) {
            Component c = color(announce);
            for (Player s : Bukkit.getOnlinePlayers()) {
                if (s.hasPermission("zwiceac.alerts")) s.sendMessage(c);
            }
        }
        log(LocalDateTime.now() + " | PUNISH | " + p.getName() + " | " + check);

        for (String cmd : plugin.getConfig().getStringList("punishment.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    cmd.replace("%player%", p.getName()).replace("%check%", check));
        }
        if (plugin.getConfig().getBoolean("punishment.kick", true)) {
            String reason = plugin.getConfig().getString("punishment.kick-message", "Hile tespit edildi")
                    .replace("%check%", check);
            p.kick(color(reason));
        }
        if (plugin.getConfig().getBoolean("punishment.reset-vl-after-punish", true)) {
            d.vl.clear();
        }
    }

    public void decay() {
        double amount = plugin.num("vl-decay.amount", 1.0);
        for (PlayerData d : plugin.allData()) {
            Iterator<Map.Entry<String, Double>> it = d.vl.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Double> en = it.next();
                double nv = en.getValue() - amount;
                if (nv <= 0) it.remove(); else en.setValue(nv);
            }
        }
    }

    private void log(String line) {
        if (!plugin.getConfig().getBoolean("logging.file", true)) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            synchronized (FILE_LOCK) {
                try {
                    Path f = plugin.getDataFolder().toPath().resolve("violations.log");
                    Files.createDirectories(f.getParent());
                    Files.writeString(f, line + System.lineSeparator(), StandardCharsets.UTF_8,
                            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException ignored) { }
            }
        });
    }
}
