package dev.zwice.ac;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.vehicle.VehicleExitEvent;

public final class ConnectionListener implements Listener {

    private final ZwiceAC plugin;

    public ConnectionListener(ZwiceAC plugin) {
        this.plugin = plugin;
    }

    private void touch(Player p) {
        PlayerData d = plugin.data(p);
        d.lastTeleport = System.currentTimeMillis();
        d.resetMotion();
        d.lastSafe = p.getLocation().clone();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { plugin.remove(e.getPlayer().getUniqueId()); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTeleport(PlayerTeleportEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onGameMode(PlayerGameModeChangeEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onFlight(PlayerToggleFlightEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onRiptide(PlayerRiptideEvent e) { touch(e.getPlayer()); }

    @EventHandler
    public void onGlide(EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player p) plugin.data(p).lastVelocity = System.currentTimeMillis();
    }

    @EventHandler
    public void onVehicleExit(VehicleExitEvent e) {
        if (e.getExited() instanceof Player p) touch(p);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) plugin.data(p).lastDamaged = System.currentTimeMillis();
    }
}
