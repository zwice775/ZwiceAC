package dev.zwice.ac;

import org.bukkit.Location;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PlayerData {
    public final UUID uuid;
    public final Map<String, Double> vl = new HashMap<>();
    public final Map<String, Long> lastAlert = new HashMap<>();
    public final Map<UUID, Long> targets = new HashMap<>();
    private final Map<String, Double> buffers = new HashMap<>();

    public final ArrayDeque<Long> hits = new ArrayDeque<>();
    public final ArrayDeque<Long> swings = new ArrayDeque<>();
    public final ArrayDeque<Long> places = new ArrayDeque<>();
    public final ArrayDeque<Long> breaks = new ArrayDeque<>();
    public final ArrayDeque<Long> hiddenOres = new ArrayDeque<>();

    public Location lastSafe;
    public Location digLoc;
    public long digStart;

    public double lastDy, lastH;
    public int airTicks, waterTicks, moveCount;
    public boolean lastGround = true;
    public long lastTeleport, lastVelocity, lastSpecial, lastDamaged, lastIce, windowStart, bypassCheck;
    public boolean bypass, exempt;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.lastTeleport = System.currentTimeMillis();
    }

    public double addBuffer(String key, double delta) {
        double v = Math.max(0.0, buffers.getOrDefault(key, 0.0) + delta);
        buffers.put(key, v);
        return v;
    }

    public void resetBuffer(String key) {
        buffers.remove(key);
    }

    public int record(ArrayDeque<Long> q, long now, long window) {
        q.addLast(now);
        while (!q.isEmpty() && now - q.peekFirst() > window) q.pollFirst();
        while (q.size() > 300) q.pollFirst();
        return q.size();
    }

    public void resetMotion() {
        airTicks = 0;
        lastDy = 0;
        lastH = 0;
        waterTicks = 0;
    }
}
