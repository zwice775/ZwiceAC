package dev.zwice.ac;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ZwiceAC extends JavaPlugin {

    private final Map<UUID, PlayerData> dataMap = new ConcurrentHashMap<>();
    private ViolationManager violations;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        violations = new ViolationManager(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new ConnectionListener(this), this);
        pm.registerEvents(new MovementListener(this), this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(new WorldListener(this), this);

        ZwiceCommand cmd = new ZwiceCommand(this);
        PluginCommand pc = getCommand("zwiceac");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        long period = Math.max(1L, (long) getConfig().getDouble("vl-decay.interval-seconds", 30)) * 20L;
        getServer().getScheduler().runTaskTimer(this, violations::decay, period, period);

        for (Player p : getServer().getOnlinePlayers()) data(p);
        getLogger().info("Zwice AC v" + getPluginMeta().getVersion() + " aktif.");
    }

    @Override
    public void onDisable() {
        dataMap.clear();
    }

    public ViolationManager violations() { return violations; }

    public PlayerData data(Player p) {
        return dataMap.computeIfAbsent(p.getUniqueId(), PlayerData::new);
    }

    public void remove(UUID id) { dataMap.remove(id); }

    public Collection<PlayerData> allData() { return dataMap.values(); }

    public boolean enabled(String check) {
        return getConfig().getBoolean("checks." + check + ".enabled", true);
    }

    public double num(String path, double def) {
        return getConfig().getDouble(path, def);
    }

    /** Sunucu veya oyuncu laglıysa hareket kontrolleri atlanır. */
    public boolean laggy(Player p) {
        try {
            double[] tps = Bukkit.getTPS();
            if (tps.length > 0 && tps[0] < num("lag-protection.min-tps", 17.0)) return true;
        } catch (Throwable ignored) { }
        return p.getPing() > num("lag-protection.max-ping", 450);
    }

    public boolean shouldCheck(Player p) {
        if (!getConfig().getBoolean("enabled", true)) return false;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;
        if (p.hasMetadata("NPC")) return false;
        PlayerData d = data(p);
        long now = System.currentTimeMillis();
        if (now - d.bypassCheck > 5000) {
            d.bypass = p.hasPermission("zwiceac.bypass");
            d.bypassCheck = now;
        }
        return !d.bypass && !d.exempt;
    }
}
