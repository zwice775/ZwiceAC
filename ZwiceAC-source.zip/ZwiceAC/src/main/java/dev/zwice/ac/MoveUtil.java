package dev.zwice.ac;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

import java.util.EnumSet;
import java.util.Set;

final class MoveUtil {

    private MoveUtil() { }

    static final Set<Material> SPECIAL = EnumSet.of(
            Material.COBWEB, Material.HONEY_BLOCK, Material.SLIME_BLOCK, Material.POWDER_SNOW,
            Material.BUBBLE_COLUMN, Material.SWEET_BERRY_BUSH, Material.WATER, Material.LAVA,
            Material.SCAFFOLDING, Material.KELP, Material.KELP_PLANT, Material.SEAGRASS,
            Material.TALL_SEAGRASS);

    static BoundingBox box(Player p, Location l, double shrink) {
        double hw = p.getWidth() / 2.0 - shrink;
        return new BoundingBox(l.getX() - hw, l.getY() + shrink, l.getZ() - hw,
                l.getX() + hw, l.getY() + p.getHeight() - shrink, l.getZ() + hw);
    }

    static boolean collides(World w, BoundingBox box) {
        int minX = (int) Math.floor(box.getMinX()), maxX = (int) Math.floor(box.getMaxX());
        int minY = (int) Math.floor(box.getMinY()), maxY = (int) Math.floor(box.getMaxY());
        int minZ = (int) Math.floor(box.getMinZ()), maxZ = (int) Math.floor(box.getMaxZ());
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int y = minY; y <= maxY; y++) {
                    Block b = w.getBlockAt(x, y, z);
                    if (b.isPassable()) continue;
                    for (BoundingBox bb : b.getCollisionShape().getBoundingBoxes()) {
                        if (bb.shift(x, y, z).overlaps(box)) return true;
                    }
                }
            }
        }
        return false;
    }

    /** Oyuncunun ayağının altında (tol kadar) katı blok var mı? */
    static boolean onGround(Player p, Location l, double tol) {
        double hw = p.getWidth() / 2.0 - 0.001;
        BoundingBox b = new BoundingBox(l.getX() - hw, l.getY() - tol, l.getZ() - hw,
                l.getX() + hw, l.getY() + 0.1, l.getZ() + hw);
        return collides(l.getWorld(), b);
    }

    /** Su, lav, merdiven, ağ, bal vb. özel blok yakınında mı? */
    static boolean special(Location l) {
        World w = l.getWorld();
        int minX = (int) Math.floor(l.getX() - 0.31), maxX = (int) Math.floor(l.getX() + 0.31);
        int minZ = (int) Math.floor(l.getZ() - 0.31), maxZ = (int) Math.floor(l.getZ() + 0.31);
        int y = l.getBlockY();
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int dy = -1; dy <= 1; dy++) {
                    Material m = w.getBlockAt(x, y + dy, z).getType();
                    if (SPECIAL.contains(m) || Tag.CLIMBABLE.isTagged(m) || Tag.BEDS.isTagged(m)) return true;
                }
            }
        }
        return false;
    }

    static boolean onIce(Location l) {
        World w = l.getWorld();
        int x = l.getBlockX(), z = l.getBlockZ();
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return false;
        for (int dy = 1; dy <= 2; dy++) {
            Material m = w.getBlockAt(x, (int) Math.floor(l.getY() - 0.5) - dy + 1, z).getType();
            if (Tag.ICE.isTagged(m)) return true;
        }
        return false;
    }

    /** Oyuncunun etrafında (ayak/baş hizasında) katı blok var mı? */
    static boolean obstructed(Location l) {
        World w = l.getWorld();
        int x0 = l.getBlockX(), y0 = l.getBlockY(), z0 = l.getBlockZ();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (!w.isChunkLoaded((x0 + dx) >> 4, (z0 + dz) >> 4)) continue;
                for (int dy = 0; dy <= 1; dy++) {
                    if (!w.getBlockAt(x0 + dx, y0 + dy, z0 + dz).isPassable()) return true;
                }
            }
        }
        return false;
    }
}
