package dev.zwice.ac;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.Locale;

public final class CombatListener implements Listener {

    private final ZwiceAC plugin;

    public CombatListener(ZwiceAC plugin) {
        this.plugin = plugin;
    }

    private String f(double v) { return String.format(Locale.ROOT, "%.2f", v); }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!plugin.shouldCheck(p)) return;

        Entity target = e.getEntity();
        if (target.getWorld() != p.getWorld()) return;

        PlayerData d = plugin.data(p);
        long now = System.currentTimeMillis();
        ZwiceAC pl = plugin;
        ViolationManager vm = pl.violations();

        Location eyeLoc = p.getEyeLocation();
        Vector eye = eyeLoc.toVector();
        BoundingBox box = target.getBoundingBox();
        Vector closest = new Vector(
                clamp(eye.getX(), box.getMinX(), box.getMaxX()),
                clamp(eye.getY(), box.getMinY(), box.getMaxY()),
                clamp(eye.getZ(), box.getMinZ(), box.getMaxZ()));
        double dist = closest.distance(eye);

        // ---- Reach ----
        if (pl.enabled("reach")) {
            double ping = Math.min(p.getPing(), 300) / 1000.0;
            double max = pl.num("checks.reach.max-distance", 3.1) + 0.3 + ping * 2.0;
            if (dist > max) {
                double b = d.addBuffer("reach", dist > max + 0.8 ? 2 : 1);
                if (b >= 2) {
                    if (vm.flag(p, "reach", f(dist) + " > " + f(max), 1)) {
                        e.setCancelled(true);
                        return;
                    }
                }
            } else {
                d.addBuffer("reach", -0.25);
            }
        }

        // ---- KillAura: bakış açısı ----
        if (pl.enabled("killaura") && dist > 1.2) {
            Vector look = eyeLoc.getDirection();
            Vector toCenter = box.getCenter().subtract(eye);
            double angle = Math.toDegrees(look.angle(toCenter));
            double maxAngle = pl.num("checks.killaura.max-angle", 90);
            if (angle > maxAngle) {
                double b = d.addBuffer("aura-angle", 1);
                if (b >= 2 && vm.flag(p, "killaura", "açı=" + f(angle), 1)) {
                    e.setCancelled(true);
                    return;
                }
            } else {
                d.addBuffer("aura-angle", -0.5);
            }
        }

        // ---- KillAura: duvar arkası ----
        if (pl.enabled("killaura") && dist > 0.6) {
            Vector dir = closest.clone().subtract(eye).normalize();
            RayTraceResult r = p.getWorld().rayTraceBlocks(eyeLoc, dir, dist - 0.05,
                    FluidCollisionMode.NEVER, true);
            if (r != null && r.getHitBlock() != null) {
                double b = d.addBuffer("aura-wall", 1);
                if (b >= 3 && vm.flag(p, "killaura", "duvar arkası", 1)) {
                    e.setCancelled(true);
                    return;
                }
            } else {
                d.addBuffer("aura-wall", -0.5);
            }
        }

        // ---- KillAura: çoklu hedef ----
        if (pl.enabled("killaura")) {
            d.targets.put(target.getUniqueId(), now);
            d.targets.values().removeIf(t -> now - t > 600);
            int maxT = (int) pl.num("checks.killaura.max-targets", 3);
            if (d.targets.size() >= maxT) {
                d.targets.clear();
                if (vm.flag(p, "killaura", "çoklu hedef", 1)) {
                    e.setCancelled(true);
                    return;
                }
            }
        }

        // ---- AutoClicker (vuruş hızı) ----
        if (pl.enabled("autoclicker")) {
            int c = d.record(d.hits, now, 1000);
            double maxCps = pl.num("checks.autoclicker.max-cps", 22);
            if (c > maxCps) {
                if (vm.flag(p, "autoclicker", "vuruş/sn=" + c, 1)) e.setCancelled(true);
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        if (!plugin.shouldCheck(p) || !plugin.enabled("autoclicker")) return;

        // Blok kırarken sürekli sallanma olur; sadece havaya tıklamaları say
        Block targetBlock = p.getTargetBlockExact(6);
        if (targetBlock != null) return;

        PlayerData d = plugin.data(p);
        int c = d.record(d.swings, System.currentTimeMillis(), 1000);
        double maxCps = plugin.num("checks.autoclicker.max-cps", 22);
        if (c > maxCps) {
            if (plugin.violations().flag(p, "autoclicker", "CPS=" + c, 1)) e.setCancelled(true);
        }
    }
}
